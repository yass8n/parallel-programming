#!/bin/bash 
while [  TRUE ]; do
echo running
sleep 10
done
