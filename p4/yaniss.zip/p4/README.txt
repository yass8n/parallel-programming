Compile with 'make' to create the executable "./parallel_execute"
The results of all the runs are in /output/output.txt

To run the executbale, type

./parallel_execute <n> <num_threads>